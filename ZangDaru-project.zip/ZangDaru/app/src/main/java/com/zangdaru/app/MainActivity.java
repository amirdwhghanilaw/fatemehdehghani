package com.zangdaru.app;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private Ui.Pal p;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
        Alarms.scheduleAll(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        build();
    }

    @Override
    public void onRequestPermissionsResult(int rc, String[] perms, int[] res) {
        super.onRequestPermissionsResult(rc, perms, res);
        build();
    }

    private void build() {
        p = Ui.pal(this);
        int pad = Ui.dp(this, 16);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(p.bg);
        sv.setFillViewport(true);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, pad, pad, pad);
        sv.addView(col);

        // ---- header ----
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setBackground(Ui.box(this, p.primary, 24));
        head.setPadding(pad, pad, pad, pad);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        head.addView(logo, new LinearLayout.LayoutParams(Ui.dp(this, 72), Ui.dp(this, 72)));
        LinearLayout tc = new LinearLayout(this);
        tc.setOrientation(LinearLayout.VERTICAL);
        tc.setPadding(pad, 0, pad, 0);
        tc.addView(Ui.text(this, "زنگ دارو", 30, Color.WHITE, true));
        tc.addView(Ui.text(this, "یادآور ساعت مصرف دارو", 16, Color.WHITE, false));
        head.addView(tc);
        col.addView(head, Ui.lp(this, Ui.MATCH, Ui.WRAP, 0));

        // ---- notifications warning ----
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (!nm.areNotificationsEnabled()) {
            LinearLayout warn = new LinearLayout(this);
            warn.setOrientation(LinearLayout.VERTICAL);
            warn.setBackground(Ui.box(this, 0xFFFFE0B2, 16));
            warn.setPadding(pad, pad, pad, pad);
            warn.addView(Ui.text(this, "⚠️ اعلان‌های برنامه خاموش است و زنگ دارو به‌درستی کار نمی‌کند.", 17, 0xFF5D4037, true));
            TextView fix = Ui.button(this, "روشن کردن اعلان‌ها", 0xFFFB8C00, Color.WHITE);
            fix.setOnClickListener(v -> openNotificationSettings());
            warn.addView(fix, Ui.lp(this, Ui.MATCH, Ui.WRAP, 10));
            col.addView(warn, Ui.lp(this, Ui.MATCH, Ui.WRAP, 12));
        }

        // ---- add button ----
        TextView add = Ui.button(this, "➕  افزودن داروی جدید", p.primary, Color.WHITE);
        add.setTextSize(22);
        add.setOnClickListener(v -> startActivity(new Intent(this, EditActivity.class)));
        col.addView(add, Ui.lp(this, Ui.MATCH, Ui.dp(this, 68), 16));

        // ---- medicines ----
        ArrayList<Med> meds = Store.all(this);
        if (meds.isEmpty()) {
            TextView empty = Ui.text(this, "هنوز دارویی اضافه نکرده‌اید.\nروی «افزودن داروی جدید» بزنید.", 18, p.text, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(pad, Ui.dp(this, 32), pad, Ui.dp(this, 32));
            col.addView(empty, Ui.lp(this, Ui.MATCH, Ui.WRAP, 8));
        }
        for (Med m : meds) col.addView(card(m), Ui.lp(this, Ui.MATCH, Ui.WRAP, 12));

        // ---- theme chooser ----
        col.addView(Ui.text(this, "رنگ برنامه", 18, p.text, true), Ui.lp(this, Ui.WRAP, Ui.WRAP, 28));
        LinearLayout tr = new LinearLayout(this);
        tr.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < Ui.PALS.length; i++) {
            final int k = i;
            boolean sel = (i == Store.theme(this));
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 8));
            View dot = new View(this);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(Ui.DOTS[i]);
            g.setStroke(Ui.dp(this, sel ? 4 : 1), sel ? 0xFF263238 : 0xFFB0BEC5);
            dot.setBackground(g);
            cell.addView(dot, new LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44)));
            cell.addView(Ui.text(this, Ui.THEME_NAMES[i], 14, p.text, sel));
            cell.setOnClickListener(v -> { Store.setTheme(this, k); build(); });
            tr.addView(cell, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        }
        col.addView(tr, Ui.lp(this, Ui.MATCH, Ui.WRAP, 4));

        TextView about = Ui.button(this, "ℹ️  درباره برنامه", p.soft, p.text);
        about.setOnClickListener(v -> startActivity(new Intent(this, AboutActivity.class)));
        col.addView(about, Ui.lp(this, Ui.MATCH, Ui.WRAP, 20));

        Ui.apply(this, sv);
    }

    private View card(Med m) {
        int pad = Ui.dp(this, 12);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(Ui.box(this, p.soft, 20));
        row.setPadding(pad, pad, pad, pad);

        int size = Ui.dp(this, 76);
        if (m.hasPhoto()) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            Bitmap bmp = Ui.decodeFile(m.photo, 300);
            iv.setImageBitmap(bmp);
            row.addView(iv, new LinearLayout.LayoutParams(size, size));
        } else {
            TextView pill = Ui.text(this, "💊", 36, p.text, false);
            pill.setGravity(Gravity.CENTER);
            pill.setBackground(Ui.box(this, Color.WHITE, 16));
            row.addView(pill, new LinearLayout.LayoutParams(size, size));
        }
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(pad, 0, pad, 0);
        info.addView(Ui.text(this, m.name, 22, p.text, true));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < m.times.size(); i++) {
            if (i > 0) sb.append(" ، ");
            sb.append(Ui.fa(m.times.get(i)));
        }
        info.addView(Ui.text(this, "🕐 " + sb, 18, p.text, false));
        int left = m.daysLeft();
        String rest = left > 0 ? Ui.fa(String.valueOf(left)) + " روز مانده" : "دوره‌ی مصرف تمام شد";
        info.addView(Ui.text(this, rest, 15, p.primary, true));
        row.addView(info, new LinearLayout.LayoutParams(0, Ui.WRAP, 1f));
        row.setOnClickListener(v -> {
            Intent i = new Intent(this, EditActivity.class);
            i.putExtra("id", m.id);
            startActivity(i);
        });
        return row;
    }

    private void openNotificationSettings() {
        Intent i;
        if (Build.VERSION.SDK_INT >= 26) {
            i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
        } else {
            i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:" + getPackageName()));
        }
        startActivity(i);
    }
}
