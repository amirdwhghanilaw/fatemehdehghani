package com.zangdaru.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import java.util.ArrayList;

final class Store {
    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("zd", Context.MODE_PRIVATE);
    }

    static ArrayList<Med> all(Context c) {
        ArrayList<Med> l = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp(c).getString("meds", "[]"));
            for (int i = 0; i < a.length(); i++) l.add(Med.from(a.getJSONObject(i)));
        } catch (JSONException e) { /* ignore */ }
        return l;
    }

    private static void write(Context c, ArrayList<Med> l) {
        JSONArray a = new JSONArray();
        try {
            for (Med m : l) a.put(m.toJson());
        } catch (JSONException e) { /* ignore */ }
        sp(c).edit().putString("meds", a.toString()).apply();
    }

    static Med get(Context c, int id) {
        for (Med m : all(c)) if (m.id == id) return m;
        return null;
    }

    static void save(Context c, Med m) {
        ArrayList<Med> l = all(c);
        boolean found = false;
        for (int i = 0; i < l.size(); i++) {
            if (l.get(i).id == m.id) { l.set(i, m); found = true; }
        }
        if (!found) l.add(m);
        write(c, l);
    }

    static void remove(Context c, int id) {
        ArrayList<Med> l = all(c);
        for (int i = l.size() - 1; i >= 0; i--) if (l.get(i).id == id) l.remove(i);
        write(c, l);
    }

    static int nextId(Context c) {
        int id = sp(c).getInt("nextId", 1);
        sp(c).edit().putInt("nextId", id + 1).apply();
        return id;
    }

    static int theme(Context c) {
        int t = sp(c).getInt("theme", 0);
        return (t < 0 || t >= Ui.PALS.length) ? 0 : t;
    }

    static void setTheme(Context c, int t) { sp(c).edit().putInt("theme", t).apply(); }
}
