package com.zangdaru.app;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;

final class Med {
    int id;
    String name = "", note = "", photo = "";
    ArrayList<String> times = new ArrayList<>();
    long startMs;
    int days = 7;

    boolean hasPhoto() { return photo != null && !photo.isEmpty() && new File(photo).exists(); }

    long endMs() {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(startMs);
        c.add(Calendar.DAY_OF_YEAR, days);
        return c.getTimeInMillis();
    }

    int daysLeft() {
        long d = endMs() - System.currentTimeMillis();
        return d <= 0 ? 0 : (int) Math.ceil(d / 86400000.0);
    }

    static long todayStart() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("name", name);
        o.put("note", note);
        o.put("photo", photo == null ? "" : photo);
        o.put("start", startMs);
        o.put("days", days);
        JSONArray a = new JSONArray();
        for (String t : times) a.put(t);
        o.put("times", a);
        return o;
    }

    static Med from(JSONObject o) throws JSONException {
        Med m = new Med();
        m.id = o.getInt("id");
        m.name = o.optString("name", "");
        m.note = o.optString("note", "");
        m.photo = o.optString("photo", "");
        m.startMs = o.optLong("start", todayStart());
        m.days = o.optInt("days", 7);
        JSONArray a = o.optJSONArray("times");
        if (a != null) for (int i = 0; i < a.length(); i++) m.times.add(a.getString(i));
        return m;
    }
}
