package com.zangdaru.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class AboutActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.Pal p = Ui.pal(this);
        int pad = Ui.dp(this, 20);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(p.bg);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(pad, pad, pad, pad);
        sv.addView(col);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        col.addView(logo, new LinearLayout.LayoutParams(Ui.dp(this, 128), Ui.dp(this, 128)));
        TextView t = Ui.text(this, "زنگ دارو", 32, p.primary, true);
        col.addView(t, Ui.lp(this, Ui.WRAP, Ui.WRAP, 8));

        TextView d = Ui.text(this, getString(R.string.app_description), 19, p.text, false);
        d.setLineSpacing(0, 1.3f);
        d.setBackground(Ui.box(this, p.soft, 20));
        d.setPadding(pad, pad, pad, pad);
        col.addView(d, Ui.lp(this, Ui.MATCH, Ui.WRAP, 20));

        col.addView(Ui.text(this, "نسخه ۱٫۰", 15, p.text, false), Ui.lp(this, Ui.WRAP, Ui.WRAP, 16));
        TextView back = Ui.button(this, "بازگشت", p.primary, Color.WHITE);
        back.setOnClickListener(v -> finish());
        col.addView(back, Ui.lp(this, Ui.MATCH, Ui.WRAP, 20));
        Ui.apply(this, sv);
    }
}
