package com.zangdaru.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent in) {
        String a = in.getAction();
        if (Alarms.ACT_TAKEN.equals(a)) {
            Alarms.dismiss(c, in.getIntExtra("nid", 0));
            return;
        }
        if (Alarms.ACT_SNOOZE.equals(a)) {
            Alarms.snooze(c, in.getIntExtra("med", -1), in.getIntExtra("idx", 0), in.getIntExtra("nid", 0));
            return;
        }
        int medId = in.getIntExtra("med", -1);
        int idx = in.getIntExtra("idx", 0);
        Med m = Store.get(c, medId);
        if (m == null || idx >= m.times.size()) return;
        if (!in.getBooleanExtra("snooze", false)) {
            // schedule the same time slot for the next day (if the course is not over)
            long t = Alarms.nextTrigger(m, idx, System.currentTimeMillis() + 60000);
            if (t > 0) Alarms.setAt(c, t, Alarms.slotPi(c, medId, idx, false));
        }
        Alarms.ring(c, m, idx);
    }
}
